﻿namespace Chat.Model.Business
{
    public interface ILogger
    {
        void Update();
    }
}
